# TedXMedi-Caps
Website for TEDx Medi-Caps University
